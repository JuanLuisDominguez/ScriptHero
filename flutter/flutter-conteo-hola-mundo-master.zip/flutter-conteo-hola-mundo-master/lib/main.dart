import 'package:flutter/material.dart';

// Nosotros escribimos
// import 'src/app.dart';
import 'package:contador/src/app.dart';

void main() {

  runApp( MyApp() );

}


